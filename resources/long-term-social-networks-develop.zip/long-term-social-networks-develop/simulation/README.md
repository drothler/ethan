# To read the graph in the networkx do the following:
```
import networkx as nx
graph = nx.read_gpickle("graph.gexf")
```

## Also attached is the graph in xml format