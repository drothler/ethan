# Group of Long-term Social Networks
## Most recent updates about our work will be poster here

## Members: Aldi Topalli, Miriam Anschütz (alphabetically ordered)